% Load data
load("Rotary_Poten_A.mat");

% Define percentages and calculate y values
percentages = 0:5:100;
y = zeros(size(percentages));

for i = 1:length(percentages)
    data = eval(sprintf('RA_%dper', percentages(i)));
    y(i) = (mean(data) / 4096) * 3.3;
    y(i) = (y(i) / 3.3) * 100;
end

% Define x, datax, and datay
x = percentages;
datax = [12.98, 19.94, 25.11, 29.83, 34.23, 39.85, 44.79, 49.60, 54.45, 59.80, 64.96, 69.64, 74.44, 79.79, 84.64, 89.99, 94.75];
datay = [0.45, 1.21, 1.89, 2.79, 4.05, 5.80, 7.46, 9.44, 12.04, 15.73, 21.66, 31.27, 45.02, 58.72, 71.48, 85.55, 97.63];
error = 0.2 * datay;

% Plot the first data set
plot(x, y, 'b-', 'LineWidth', 1.5, 'DisplayName', 'Measured Data');
hold on;

% Plot the second data set
plot(datax, datay, 'r-', 'LineWidth', 1.5, 'DisplayName', 'Datasheet');
errorbar(datax, datay, error, 'b', 'LineStyle', 'none', 'CapSize', 5, 'DisplayName', 'Errorbar')

% Customize the plot
title('Rotary Potentiometer Type A');
xlabel('Rotational Travel (%)');
ylabel('Percent Voltage (%)');
grid on;
legend('show');
hold off;