% Load data
load("Rotary_Poten_C.mat");

% Define percentages and calculate y values
percentages = 0:5:100;
y = zeros(size(percentages));

for i = 1:length(percentages)
    data = eval(sprintf('RC_%dper', percentages(i)));
    y(i) = (mean(data) / 4096) * 3.3;
    y(i) = 100 - ((y(i) / 3.3) * 100);
end

% Define x, datax, and datay
x = percentages;
datax = [3.87, 9.65, 14.49, 19.33, 24.04, 29.57, 34.03, 39.63, 44.59, 49.81, 54.34, 59.68, 64.27, 69.61, 74.51, 80.04, 84.82, 89.72];
datay = [99.35, 86.84, 75.66, 62.83, 51.83, 38.32, 29.71, 21.92, 17.27, 14.63, 12.55, 10.04, 8.03, 5.51, 3.88, 2.06, 1.05, 0.23];
error = 0.2 * datay;

% Plot the first data set
plot(x, y, 'b-', 'LineWidth', 1.5, 'DisplayName', 'Measured Data');
hold on;

% Plot the second data set
plot(datax, datay, 'r-', 'LineWidth', 1.5, 'DisplayName', 'Datasheet');
errorbar(datax, datay, error, 'b', 'LineStyle', 'none', 'CapSize', 5, 'DisplayName', 'Errorbar')

% Customize the plot
title('Rotary Potentiometer Type C');
xlabel('Rotational Travel (%)');
ylabel('Percent Voltage (%)');
grid on;
legend('show');
hold off;