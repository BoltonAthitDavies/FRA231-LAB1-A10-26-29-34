% Load data
load("Linear_Poten_B.mat");

% Define percentages and calculate y values
percentages = 0:5:100;
y = zeros(size(percentages));

for i = 1:length(percentages)
    data = eval(sprintf('LB_%dper', percentages(i)));
    y(i) = (mean(data) / 4096) * 3.3;
    y(i) = (y(i) / 3.3) * 100;
end

% Define x, datax, and datay
x = percentages;
datax = [6.33, 9.46, 14.42, 19.65, 24.14, 29.73, 34.50, 39.68, 44.54, 49.56, 54.16, 59.84, 64.12, 69.79, 74.07, 79.75, 84.85, 90.11, 92.82];
datay = [0.45, 0.84, 1.75, 3.45, 6.03, 11.54, 19.85, 29.23, 38.52, 48.15, 55.22, 62.71, 68.96, 77.76, 83.77, 92.49, 95.94, 97.42, 98.00];
error = 0.2 * datay;

% Plot the first data set
plot(x, y, 'b-', 'LineWidth', 1.5, 'DisplayName', 'Measured Data');
hold on;

% Plot the second data set
plot(datax, datay, 'r-', 'LineWidth', 1.5, 'DisplayName', 'Datasheet');
errorbar(datax, datay, error, 'b', 'LineStyle', 'none', 'CapSize', 5, 'DisplayName', 'Errorbar')

% Customize the plot
title('Linear Potentiometer Type B');
xlabel('Rotational Travel (%)');
ylabel('Percent Voltage (%)');
grid on;
legend('show');
hold off;

disp(y)