% Load data
load("LA.mat");

% Define percentages and calculate y values
percentages = 0:3:60;
y = zeros(size(percentages));

for i = 1:length(percentages)
    data = eval(sprintf('mm%d', percentages(i)));
    y(i) = (mean(data) / 3.3) * 100;
    y(i) = 100 - y(i);
end

% Define x, datax, and datay
x = 0:5:100;
datax = [5.47, 9.72, 14.53, 19.98, 24.87, 29.86, 34.20, 39.86, 44.99, 49.83, 54.45, 60.02, 65.07, 69.99, 75.19, 80.03, 85.23, 90.07, 93.22];
datay = [0.61, 1.08, 1.63, 2.65, 3.85, 5.88, 8.19, 10.73, 13.07, 15.35, 17.91, 22.53, 29.71, 39.61, 51.77, 63.65, 76.18, 87.91, 96.05];
error = 0.2 * datay;

% Plot the first data set
plot(x, y, 'b-', 'LineWidth', 1.5, 'DisplayName', 'Measured Data');
hold on;

% Plot the second data set
plot(datax, datay, 'r-', 'LineWidth', 1.5, 'DisplayName', 'Datasheet');
errorbar(datax, datay, error, 'b', 'LineStyle', 'none', 'CapSize', 5, 'DisplayName', 'Errorbar')

% Customize the plot
title('Linear Potentiometer Type A');
xlabel('Rotational Travel (%)');
ylabel('Percent Voltage (%)');
grid on;
legend('show');
hold off;