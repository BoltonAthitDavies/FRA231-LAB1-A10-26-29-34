% % Calculate the average of the first 1000 values
% sub_value = mean(double(kg10(1:1000)));
% 
% lc_value = [lc_value, sub_value]; % Append the average to the array
% 
% % Display the result
% disp(lc_value);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x = linspace(0, 10, 11);  
y = abs(lc_value - 0.0353);  % Calculate the y values based on load cell data
Y = linspace(0, 2.5, 11);    % Example reference values for comparison

measured_error = abs(y - Y); % Absolute error
avg_err = 0;

figure;
errorbar(x, y, measured_error, '-o', 'DisplayName', 'Measured Data'); % Add error bars based on calculated error
hold on;

plot(x, Y, '-o', 'DisplayName', 'Reference Data');

for i = 1:length(x)
    text(x(i), y(i) + measured_error(i), sprintf('%.3f', measured_error(i)), 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'center');
    avg_err = avg_err + measured_error(i);
end

disp(avg_err/11);
title('Load Cell Output with Calculated Errors');
xlabel('Weight (kg.)');
ylabel('Voltage (V)');

grid on; 
legend show;




% % Create the first subplot
% subplot(2, 1, 1); % 2 rows, 1 column, first subplot
% plot(x, y, '-o'); % Plot the first set of values
% title('Measured Load Cell voltage');
% xlabel('Weight (kg.)');
% ylabel('Voltage');
% grid on;
% disp(y)
% 
% % Create the second subplot
% subplot(2, 1, 2); % 2 rows, 1 column, second subplot
% plot(x, y*4, '-o'); % Plot the second set of values
% title('Calculated Load Cell Weight');
% xlabel('Actual Weight (kg.)');
% ylabel('Measured Weight (kg.)');
% grid on;
% 



Rg = 118;
Gain = 4 + (60000 / Rg);
Vin = [0.1;0.4;0.9;1.4;1.8;2.3;2.8;3.3;3.7;3.8;3.8] * 0.001;
Vout = (Vin) * Gain;

x2 = x;
y2 = Vout;
% % Create the third subplot
% subplot(2, 2, 3); % 2 rows, 1 column, first subplot
% plot(x, y * 4, '-o'); % Plot the first set of values
% title('Measured Load Cell weight');
% xlabel('Weight (kg.)');
% ylabel('Measured Weight (kg.)');
% grid on;
% 
% % Create the forth subplot
% subplot(2, 2, 4); % 2 rows, 1 column, second subplot
% plot(x2, y2 * 4, '-o'); % Plot the second set of values
% title('Calculated Load Cell weight');
% xlabel('Weight (kg.)');
% ylabel('Measured Weight (kg.)');
% grid on;
