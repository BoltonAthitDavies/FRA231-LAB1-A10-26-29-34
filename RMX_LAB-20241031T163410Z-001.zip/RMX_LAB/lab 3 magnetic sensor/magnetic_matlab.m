% % Calculate the average of the first 1000 values
% sub_value = mean(Uns_0S*(3.3/4095));
% 
% m_value = [m_value, sub_value]; % Append the average to the array
% 
% % Display the result
% disp(m_value);

x = linspace(-35, 35, 72); 
xN = linspace(-35, 0, 36);
xS = linspace(0, 35, 36);

y = m_value * (3.3 / 4095);
yN = y(:,1:36);
yS = y(:,37:72);

Vq = 1.65; %volt
Ta = 25; % celcius
Stc = 0.0012; % percentage/celcius
sen = 15; %millivolt/millitesla
yNB = (yN - 1.65) / (30*0.001);
ySB = (yS - 1.65) / (30*0.001);
yB = (y - 1.65) / (30*0.001);

subplot(2, 3, 1); 
plot(xS, yN, '-o'); 
title('Measured unshield North voltage');
xlabel('distance (mm.)');
ylabel('voltage (v)');
grid on;
disp(y)

subplot(2, 3, 2); 
plot(xS, yS, '-o'); 
title('Measured unshield South voltage');
xlabel('distance (mm.)');
ylabel('voltage (v)');
grid on;

subplot(2, 3, 3); 
plot(x, y, '-o'); 
title('Measured unshield North-South voltage');
xlabel('distance (mm.)');
ylabel('voltage (v)');
grid on;

subplot(2, 3, 4); 
plot(yNB, yN, '-o');
title('Measured unshield North magnetic flux density');
xlabel('magnetic flux density (millitesla)');
ylabel('voltage (v)');
grid on;

subplot(2, 3, 5);
plot(ySB, yS, '-o'); 
title('Measured unshield South magnetic flux density');
xlabel('magnetic flux density (millitesla)');
ylabel('voltage (v)');
grid on;

subplot(2, 3, 6); 
plot(yB, y, '-o'); 
title('Measured unshield North-South magnetic flux density');
xlabel('magnetic flux density (millitesla)');
ylabel('voltage (v)');
grid on;





% % Plot the 71 values with the specified x-axis range
% plot(x, y, '-o'); % Use '-o' to add markers for each point
% title('Hall Sensor');
% xlabel('distances (mm.)');
% ylabel('Voltage');
% grid on; % Add a grid for better visualization