% % Calculate the average of the first 1000 values
% sub_value = mean(Uns_0S*(3.3/4095));
% 
% m_value = [m_value, sub_value]; % Append the average to the array
% 
% % Display the result
% disp(m_value);

% Create an x-axis ranging from -35 to 35
x = linspace(-35, 35, 16); % Generates 71 equally spaced points between -35 and 35
xN = linspace(-35, 0, 8);
xS = linspace(0, 35, 8);

y = m_value;
yN = y(:,1:8);
yS = y(:,9:16);

Vq = 1.65; %volt
Ta = 25; % celcius
Stc = 0.0012; % percentage/celcius
sen = 15; %millivolt/millitesla
yNB = (yN - 1.65) / (30*0.001);
ySB = (yS - 1.65) / (30*0.001);
yB = (y - 1.65) / (30*0.001);

% % Plot the 71 values with the specified x-axis range
% plot(x, y, '-o'); % Use '-o' to add markers for each point
% title('Hall Sensor');
% xlabel('distances (mm.)');
% ylabel('Voltage');
% grid on; % Add a grid for better visualization

% Create the first subplot
subplot(2, 3, 1); % 2 rows, 1 column, first subplot
plot(xS, yN, '-o'); % Plot the first set of values
title('Measured shield North voltage');
xlabel('distance (mm.)');
ylabel('voltage (v)');
grid on;
disp(y)

% Create the second subplot
subplot(2, 3, 2); % 2 rows, 1 column, second subplot
plot(xS, yS, '-o'); % Plot the second set of values
title('Measured shield South voltage');
xlabel('distance (mm.)');
ylabel('voltage (v)');
grid on;

% Create the third subplot
subplot(2, 3, 3); % 2 rows, 1 column, second subplot
plot(x, y, '-o'); % Plot the second set of values
title('Measured shield North-South voltage');
xlabel('distance (mm.)');
ylabel('voltage (v)');
grid on;

% Create the forth subplot
subplot(2, 3, 4); % 2 rows, 1 column, second subplot
plot(yNB, yN, '-o'); % Plot the second set of values
title('Measured shield North magnetic flux density');
xlabel('magnetic flux density (millitesla)');
ylabel('voltage (v)');
grid on;

% Create the fifth subplot
subplot(2, 3, 5); % 2 rows, 1 column, second subplot
plot(ySB, yS, '-o'); % Plot the second set of values
title('Measured shield South magnetic flux density');
xlabel('magnetic flux density (millitesla)');
ylabel('voltage (v)');
grid on;

% Create the sixth subplot
subplot(2, 3, 6); % 2 rows, 1 column, second subplot
plot(yB, y, '-o'); % Plot the second set of values
title('Measured shield North-South magnetic flux density');
xlabel('magnetic flux density (millitesla)');
ylabel('voltage (v)');
grid on;