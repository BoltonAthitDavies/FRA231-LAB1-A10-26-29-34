% Load data
load("Rotary_Poten_B.mat");

% Define percentages and calculate y values
percentages = 0:5:100;
y = zeros(size(percentages));

for i = 1:length(percentages)
    data = eval(sprintf('RB_%dper', percentages(i)));
    y(i) = (mean(data) / 4096) * 3.3;
    y(i) = (y(i) / 3.3) * 100;
end

% Define x, datax, and datay
x = percentages;
datax = [4.57, 9.69, 14.33, 19.54, 24.62, 29.61, 34.64, 39.68, 44.49, 49.93, 54.61, 59.86, 64.10, 69.84, 74.88, 80.18, 85.48, 89.98, 94.44];
datay = [0.19, 5.49, 10.71, 16.59, 22.29, 27.68, 33.43, 38.82, 44.35, 50.18, 55.44, 61.15, 65.82, 72.24, 77.77, 83.74, 89.75, 94.47, 99.55];
error = 0.2 * datay;

% Plot the first data set
plot(x, y, 'b-', 'LineWidth', 1.5, 'DisplayName', 'Measured Data');
hold on;

% Plot the second data set
plot(datax, datay, 'r-', 'LineWidth', 1.5, 'DisplayName', 'Datasheet');
errorbar(datax, datay, error, 'b', 'LineStyle', 'none', 'CapSize', 5, 'DisplayName', 'Errorbar')

% Customize the plot
title('Rotary Potentiometer Type B');
xlabel('Rotational Travel (%)');
ylabel('Percent Voltage (%)');
grid on;
legend('show');
hold off;